/*
 * testfunctions.h
 *
 *  Created on: Nov 30, 2021
 *      Author: student
 */

#ifndef TESTFUNCTIONS_H_
#define TESTFUNCTIONS_H_

void testFall();
void testStacking();
void testCharacterDrawing();
void testCharacterMovement();


#endif /* TESTFUNCTIONS_H_ */
