
#include "xparameters.h"

volatile int* LED_PTR = XPAR_AXI_GPIO_LED_BASEADDR;

volatile int* DIG0_PTR = XPAR_AXI_APB_BRIDGE_0_BASEADDR + 0x0;
volatile int* DIG1_PTR = XPAR_AXI_APB_BRIDGE_0_BASEADDR + 16384;

int main()
{
	int cntr = 0;
	int i;

	*(LED_PTR+1) = 0x0;

	while(1)
	{
		*LED_PTR = cntr;
		*DIG0_PTR = cntr & 0xF;
		*DIG1_PTR = (cntr>>4) & 0xF;
		cntr++;

		for (i=0; i<200000; i++);
	}

}
