Simple videogame for the SPARTAN6 FPGA by Xilinx, using a self-made
VGA controller.